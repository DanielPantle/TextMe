<?php
ini_set('session.gc_maxlifetime', 604800);
session_set_cookie_params(604800);
session_start();
//unsets all values that have been set in the $_SESSION array
session_unset();
//forwards to the login
//header("Location: /frontend_design/login.php?logout=true"); //TODO Link entsprechend anpassen

?>

<html>
<head>
  <script language="javascript" type="text/javascript">
  function deleteAllStorage() {
    if (sessionStorage.userListe) {
      sessionStorage.removeItem("userListe");
    }
    if (sessionStorage.userListe) {
      sessionStorage.removeItem("userListeHash");
    }
    if (sessionStorage.chatListe) {
      sessionStorage.removeItem("chatListe");
    }
    if (sessionStorage.userListe) {
      sessionStorage.removeItem("chatListeHash");
    }
    if (sessionStorage.myUserId) {
      sessionStorage.removeItem("myUserId");
    }
    if (sessionStorage.closedView) {
      sessionStorage.removeItem("closedView");
    }
    if (sessionStorage.adminView) {
      sessionStorage.removeItem("adminView");
    }
  }
  deleteAllStorage();

  </script>
  <meta http-equiv="refresh" content="0; url=/login.php?logout=true"/>
</head>
</html>

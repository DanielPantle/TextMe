<?php
ini_set('session.gc_maxlifetime', 604800);
session_set_cookie_params(604800);
session_start();
if(!isset($_SESSION['user_id'])){ //if login in session is not set
    header("Location: /login.php");
} ?>
<!DOCTYPE html>
<html lang="en">

<head>
  <title>ElekChat</title>
  <link rel="icon" href="media/Logo_Chat_mitRand_192x192.png">
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta name="mobile-web-app-capable" content="yes">
  <link rel="manifest" href="manifest.json">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
	<link rel="stylesheet" href="styles/animate.css">
  <link rel="stylesheet" href="styles/chat.css">
  <!-- Font Awesome File -->
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
  <script src="scripts/jquery.touchSwipe.min.js"></script>
  <script src="scripts/animations.js"></script>
  <script src="scripts/main.js"></script>
</head>

<body>

  <div class="loadingScreen">
    <center><img class="logo" src="media/logo_new22.png"/></center>
  </div>

  <div class="container app">
    <div class="row app-one">

      <div class="col-xs-12 col-sm-4 side">
        <div class="side-one">
          <!-- Heading -->
          <div class="row heading">
            <div class="col-xs-2 col-sm-2">
              <img src="media/Logo_Chat_mitRand_97x60.png" id="headingLogo"/>
            </div>
            <div class="col-xs-6 col-sm-6">
              <span id="brandLogo">ElekChat</span>
            </div>
            <div class="col-xs-2 col-sm-2" data-toggle="tooltip" data-placement="bottom" title="Adminansicht umschalten">
              <a href="#" class="hidden" id="adminView"><span class="glyphicon glyphicon-eye-open fa-2x"></span></a>
            </div>
            <div class="col-xs-2 col-sm-2" data-toggle="tooltip" data-placement="bottom" title="Zur Statistikseite wechseln">
              <a href="statistics.php" class="hidden" id="statisticsLink"><span class="glyphicon glyphicon-stats fa-2x"></span></a>
            </div>
          </div>
          <!-- Heading End -->

          <!-- sideBar -->
          <div class="row sideBar" id="chatsSideBar">
          </div>
          <!-- Sidebar End -->

          <div class="row footer">
            <div class="col-xs-2 col-sm-2" data-toggle="tooltip" data-placement="top" title="Neuen Chat erstellen">
              <a href="#"><span class="fa fa-comment fa-2x" id="newChatBtn" data-toggle="modal" data-target="#newChatModal"></span></a>
            </div>
            <div class="col-xs-2 col-sm-2" data-toggle="tooltip" data-placement="top" title="Zufälligen Chat starten">
              <a href="#"><span class="glyphicon glyphicon-random fa-2x" id="randomChatBtn"></span></a>
            </div>
          </div>
        </div>
      </div>
      <!-- New Message Sidebar End -->

      <!-- Conversation Start -->
      <div class="col-xs-12 col-sm-8 conversation">
        <!-- Heading -->
        <div class="row heading">
          <div class=" col-xs-10 col-sm-7 mobile-menu-chatname">
            <div class="row chat-name">
              <div class="col-xs-12 col-sm-12">
                <span id="chatName">Chatname hier</span>
              </div>
            </div>
            <div class="row chat-users">
              <div class="col-xs-12 col-sm-12">
                  <span id="chatUsers">User hier</span>
              </div>
            </div>
          </div>
          <div class="col-sm-1 col-xs-2 mobile-menu-btn" data-toggle="tooltip" data-placement="bottom" title="User aus Chat verbannen">
            <a href="#"><span class="fa fa-ban fa-2x hidden" id="banUserBtn" data-toggle="modal" data-target="#banUserModal"></span></a>
          </div>
          <div class="col-sm-1 col-xs-2 mobile-menu-btn" data-toggle="tooltip" data-placement="bottom" title="User zu Chat hinzufügen">
            <a href="#"><span class="fa fa-user-plus fa-2x hidden" id="addUserBtn" data-toggle="modal" data-target="#addUserModal"></span></a>
          </div>
          <div class="col-sm-1 col-xs-2 mobile-menu-btn" data-toggle="tooltip" data-placement="bottom" title="Chat archivieren oder archivierten Chat laden">
            <a href="#"><span class="fa fa-archive fa-2x" id="archiveChatMenuBtn" data-toggle="modal" data-target="#archiveModal"></span></a>
          </div>
          <div class="col-sm-1 col-xs-2 mobile-menu-btn" data-toggle="tooltip" data-placement="bottom" title="Chat verlassen">
            <a href="#"><span class="glyphicon glyphicon-remove fa-2x" data-toggle="modal" data-target="#leaveCurrentChatModal"></span></a>
          </div>
          <div class="col-sm-1 col-xs-2 mobile-menu-btn" data-toggle="tooltip" data-placement="bottom" title="Abmelden">
            <a href="../logout.php"><span class="glyphicon glyphicon-log-out fa-2x"></span></a>
          </div>
          <div class="col-xs-2 hidden" id="mobileMenuBtn">
            <a href="#"><span class="glyphicon glyphicon-align-right fa-2x"></span></a>
          </div>
        </div>
        <!-- Heading End -->

        <!-- Message Box -->
        <div class="row message" id="conversation">
        </div>
        <!-- Message Box End -->

        <!-- Reply Box -->
        <div class="row reply">
          <form class="" action="index.html" method="post">
            <div class="col-xs-10 col-sm-11">
              <input class="form-control" id="inputChatMessage" type="text" onkeydown="if (event.keyCode == 13) { sendChatMsg(); return false; }" placeholder="...tippe zum chatten!">
            </div>
            <div class="col-xs-2 col-sm-1">
              <span class="glyphicon glyphicon-send" id="sendButton" aria-hidden="true"></span>
            </div>
          </form>
        </div>
        <!-- Reply Box End -->
      </div>
      <!-- Conversation End -->
    </div>
    <!-- App One End -->
  </div>
  <!-- App End -->

  <!-- Chats Arhivieren -->
  <div id="archiveModal" class="modal fade" role="dialog">
    <div class="modal-dialog">

      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title">Chats archivieren oder archivierten Chat laden</h4>
        </div>
        <div class="modal-body">
          <div class="modal-body">
            <div class="row top-space">
              <!-- <div class="col-xs-6 col-sm-6">
                <span class="btn btn-default btn-fancy disabled" type="button" id="archiveChatBtn">Diesen Chat archivieren</span>
              </div>
              <div class="col-xs-6 col-sm-6">
                <span class="btn btn-default btn-fancy" type="button" id="showArchivedChatsBtn">Archivierte Chats anzeigen</span>
              </div> -->
              <div class="col-xs-12 col-sm-12">
                <span class="btn btn-default btn-fancy disabled" type="button" id="archiveChatBtn">Diesen Chat archivieren</span>
                <span class="btn btn-default btn-fancy top-space" type="button" id="showArchivedChatsBtn">Archivierte Chats anzeigen</span>
              </div>
            </div>
          </div>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-default btn-close" data-dismiss="modal">Schließen</button>
        </div>
      </div>

    </div>
  </div>

  <!-- User adden -->
  <div id="addUserModal" class="modal fade" role="dialog">
    <div class="modal-dialog">

      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title">User zu Chat hinzufügen</h4>
        </div>
        <div class="modal-body" id="possibleUsersAdd">
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-default btn-close" data-dismiss="modal">Schließen</button>
        </div>
      </div>

    </div>
  </div>

  <!-- User bannen -->
  <div id="banUserModal" class="modal fade" role="dialog">
    <div class="modal-dialog">

      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title">User aus dem Chat entfernen</h4>
        </div>
        <div class="modal-body" id="possibleUsersToDel">
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-default btn-close" data-dismiss="modal">Schließen</button>
        </div>
      </div>

    </div>
  </div>

  <!-- Neuen Chat starten -->
  <div id="newChatModal" class="modal fade" role="dialog">
    <div class="modal-dialog">

      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title">User für neuen chat auswählen</h4>
        </div>
        <div class="modal-body" id="newChatUsers">
          <form class="modal-form" id="newChatUsers">
          </form>
        </div>
        <div class="modal-footer">
          <!-- <div class="Container"> -->
            <!-- <div class="row"> -->
              <div class="col-xs-9 col-sm-9">
                <div class="input-group" id="newChatInput">
                  <input type="text" class="form-control error-tooltip" data-placement="top" id="inputNewChatroomName" placeholder="Name für den neuen Chat..." title="Überprüfe den Chatnamen: Max. 32 Zeichen erlaubt!">
                  <span class="input-group-btn">
                    <button class="btn btn-info btn-fancy" id="submitNewChatBtn" type="button">Los!</button>
                  </span>
                </div>
              </div>
              <div class="col-xs-3 col-sm-3">
                <button type="button" class="btn btn-default btn-close" data-dismiss="modal">Schließen</button>
              </div>
            <!-- </div> -->
          <!-- </div> -->
        </div>
      </div>

    </div>
  </div>

  <!-- Chat verlassen -->
  <div id="leaveCurrentChatModal" class="modal fade" role="dialog">
    <div class="modal-dialog">

      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title">Möchtest du den aktuellen Chat wirklich verlassen?</h4>
        </div>
        <div class="modal-body">
          <div class="row top-space">
            <div class="col-xs-6 col-sm-6">
              <span class="btn btn-success" type="button" id="leaveChatSuccessBtn">Ja</span>
            </div>
            <div class="col-xs-6 col-sm-6">
              <span class="btn btn-danger" type="button" id="leaveChatCancelBtn">Nein</span>
            </div>
          </div>
        </div>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-default btn-close" data-dismiss="modal">Schließen</button>
        </div>
      </div>

    </div>
  </div>

</body>

</html>

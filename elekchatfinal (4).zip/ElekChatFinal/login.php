<?php
ini_set('session.gc_maxlifetime', 604800);
session_set_cookie_params(604800);
session_start();
include 'backend/register_functions.php';

// Logged in user will be forwarded
if(isset($_SESSION['user_id'])){
  header("Location: index.php");//TODO: richtige fertige Seite einfügen
  die();
}
else{
  if(isset($_POST["username"]) && isset($_POST["passwd"])){

    // checks if username and passwd have values
    if($_POST["username"] != "" && $_POST["passwd"] != ""){

      $username = $_POST["username"];
      $pwd = $_POST["passwd"];
      // checks if the user account is present (registered)
      if(!check_username_available($username)){
        //if account is present, this will check if the password matches and is correct
        $user_info = authenticate_user($username, $pwd);
        // return value of -1 means that the password and username dont match
        if($user_info == -1){
          header("Location: login.php?login=false");
          die();
        }
        // if the password is correct an array with the user data is returned
        else{
          $_SESSION['user_id'] = $user_info['id'];
          $_SESSION['is_global_admin'] = $user_info['is_global_admin'];
          //forward to chat when login is done and session values are set
          header("Location: index.php");

        }
      }
      //user does not exist
      else{
        header("Location: login.php?login=false");
        die();
      }
    }
    //ERROR: if username and or passwd is empty
    else{
      header("Location: login.php?login=empty");
      die();
    }
  }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
  <title>ElekChat Login</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <link rel="stylesheet" href="styles/animate.css">
  <link rel="stylesheet" href="styles/ln_styles.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
  <script type="text/javascript">
  var $_GET = {};

  $.fn.extend({
      animateCss: function (animationName) {
          var animationEnd = 'webkitAnimationEnd mozAnimationEnd MSAnimationEnd oanimationend animationend';
          this.addClass('animated ' + animationName).one(animationEnd, function () {
              $(this).removeClass('animated ' + animationName);
          });
      }
  });

  // Executed when document has fully loaded
  $(document).ready( function() {
    // Puts GET parameters into a javascript object named $_GET
    document.location.search.replace(/\??(?:([^=]+)=([^&]*)&?)/g, function () {
      function decode(s) {
        return decodeURIComponent(s.split("+").join(" "));
      }
      $_GET[decode(arguments[1])] = decode(arguments[2]);
    });

    // Animates stuff based on GET parameters
    if($_GET.login === "false") {
      shakeLogin();
    }
  });

  // Animation
  // Animations can be used like $('ID or Classname').animateCss('Animationname');
  // For more detailed informations check: https://daneden.github.io/animate.css/

  // Shake Login Form on wrong password
  function shakeLogin() {
    $('#LoginForm').animateCss('shake');
  }
  </script>
</head>

<body>

  <!-- Login Popup -->
  <!-- Modal content -->
  <div class="modal-content">
    <div class="modal-header">
      <!-- possible close button for login form -->
      <!--<span class="close" id="loginCloseButton">&times;</span>-->
      <?php if(isset($_GET['logout'])){echo '<h2>Erfolgreich abgemeldet!</h2>';} ?>
      <h2>Login</h2>
      <?php
      if(isset($_GET['login'])){
        if($_GET['login'] === 'false') {
          echo '<span style="color: red;">Benutzer existiert nicht oder Kennwort falsch</span>';
        } elseif ($_GET['login'] === 'empty') {
          echo '<span style="color: red;">Du Depp... musst schon was eingeben</span>';
        } elseif ($_GET['login'] === 'created'){
          echo '<span>Account angelegt, bitte einloggen</span>';
        }
      }
      ?>
    </div>
    <div class="modal-body">
      <form id="LoginForm" action="login.php" method="post">
        <div class="form-group">
          <input type="text" class="form-control top-space" id="inputUsername" placeholder="Benutzername" name="username"/>
          <input type="password" class="form-control top-space" id="inputPassword" placeholder="Passwort" name="passwd"/>
          <button type="submit" class="btn btn-default top-space btn-lnreg">Login</button>
        </div>
      </form>
    </div>
    <div class="modal-footer">
      <a id="linkRegister" href="register.php"><h4>Noch nicht registriert?</h4></a>
    </div>
  </div>

</body>

</html>

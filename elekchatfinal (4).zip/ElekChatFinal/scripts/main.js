var currentChatId = -1;
var intervalId;
var requestCount = 0;

$(document).ready(function() {

  ladeAlleInhalte(true);
  intervalId = setInterval(function(){ aktualisiereStorage(); }, 1000);

  // onClick Funktionen
  $('#sendButton').click(function() {
    sendChatMsg();
  });

  $('#addUserBtn').click(function() {
    fillAddUsers();
  });

  $('#banUserBtn').click(function() {
    fillDelUsers();
  });

  $('#newChatBtn').click(function() {
    fillSelectUserForChatroom();
  });

  $('#submitNewChatBtn').click(function() {
    createNewChat();
  });

  $('#randomChatBtn').click(function() {
    startRandomChat();
  });

  $('#adminViewBtn').click(function() {
    toggleAdminView();
  });

  $('#leaveChatCancelBtn').click(function() {
    $('#leaveCurrentChatModal').modal('toggle');
  });

  $('#leaveChatSuccessBtn').click(function() {
    leaveCurrentChat();
    $('#leaveCurrentChatModal').modal('toggle');
  });

  $('#archiveChatBtn').click(function() {
    if(!parseInt(sessionStorage.isMeGlobalAdmin)
          && !parseInt(sessionStorage.isAktuellerChatAdmin)) return;

    closeChat();
    $('#archiveModal').modal('toggle');
  });

  $('#showArchivedChatsBtn').click(function() {
    switchClosedChats();
    $('#archiveModal').modal('toggle');
  });

  $('#adminView').click(function() {
    toggleAdminView();
  });
});


    //refreshClosedChatsStatus();
    //refreshAdminViewStatus();

    // mit der Json als String aufrufen!
    function callChatctl(functionString, callback)
    {
        $.ajax({
            async: true,
            contentType: "application/json",
            url: '/backend/chatctl.php',
            type : "POST",
            data: functionString,
            dataType: 'json',   //data format
            success: function (response) {
                //console.log("Ajax Call Success");
                callback(response);
            },
            error: function(response, status, error) {
                alert("Fehler: "+response.responseJSON.status_log);
                if(response.status == 401){
                  window.location = "/logout.php";
                }
            }
        });
    }

    function ladeAlleInhalte(boolNeuLaden) {
        var inputText = $("#inputChatMessage").val();
        var tmpChatId = sessionStorage.aktuelleChatId;
        if (boolNeuLaden) {

            callChatctl('{"i":"check-new-data","closed":'+ ((sessionStorage.closedView == "1") ? "1" : "0" )+ ',"admin":'+ ((sessionStorage.adminView == "1") ? "1" : "0" )+ '}', function(reJson) {
                ladeAlleDatenInStorage(reJson); // läd in sessionStorage (userListe, chatListe, myUserId)

                fillChatroomFenster(); // aktualisiert
                fillChatMessagesForId(getLowestChatId()); // aktualisiert
                currentChatId = parseInt(getLowestChatId());
                //$("#eingeloggterUserName").html("Ich bin: " + getUsernameById(sessionStorage.myUserId));

                if(parseInt(sessionStorage.isMeGlobalAdmin) == 1) {
                  $('#statisticsLink').removeClass('hidden');
                  $('#adminView').removeClass('hidden');
                }
            });
        } else {

            fillChatroomFenster();
            // setzt die choosen flag nach neuem laden der sidebar wieder auf den aktuell geöffneten chat
            if (tmpChatId != undefined) {
              $('.row .sideBar-body').removeClass('choosen');
              $('#chatsSideBar').find('div[value=' + tmpChatId + ']').addClass('choosen');
              tmpChatId = undefined;
            }
            appendChatMessagesFromStorage(); // fügt an aus sessionStorage.neueNachrichtenAktuellerChat

            $("#inputChatMessage").val(inputText);
            $("#inputChatMessage").focus();
        }
    }


    function ladeAlleDatenInStorage(reJson) {
        // nur laden, wenn noch nichts da ist!
        if (!(sessionStorage.userListe && sessionStorage.chatListe && sessionStorage.myUserId)) {

            //var reJsonString = callChatctl(strCheckAll); // {"i":"check-new-data"}
            //callChatctl(strCheckAll, function(reJson) {
            //ajaxCall('{"i":"check-new-data"}', function (response) {
            //var reJson = {};//JSON.parse(reJsonString);

            if (!sessionStorage.myUserId) { //wenns noch nicht gibt
                var myId = reJson.data.user_id; // users und chats abgeschnitten, nur eigene Id
                sessionStorage.myUserId = myId;
            }
            if (!sessionStorage.userListe) { //wenns noch nicht gibt
                var userJson = reJson.data.users; // chats und eigene Id abgeschnitten, jetzt einfaches Array mit Usern
                var hashUsers = {};
                for(var i=0;i<(Object.keys(userJson).length);i++) {
                    hashUsers[userJson[i].id] = i;
                }
                sessionStorage.userListe = JSON.stringify(userJson);
                sessionStorage.userListeHash = JSON.stringify(hashUsers);
                sessionStorage.isMeGlobalAdmin = parseInt(userJson[hashUsers[sessionStorage.myUserId]].is_global_admin);
            }
            if (!sessionStorage.chatListe) { //wenns noch nicht gibt
                if(reJson.data.hasOwnProperty('chats')) {
                    var chatsJson = reJson.data.chats; // users und eigene Id abgeschnitten, array mit chaträumen; darunter chatroomId und data[] mit nachrichten
                    var hashChats = {};
                    for(var i=0;i<(Object.keys(chatsJson).length);i++) {
                        hashChats[chatsJson[i].id] = i;
                    }
                    sessionStorage.chatListe = JSON.stringify(chatsJson);
                    sessionStorage.chatListeHash = JSON.stringify(hashChats);
                }
                else { // keine Chats mitgeliefert
                    sessionStorage.chatListe = "";
                    sessionStorage.chatListeHash = "";
                }
            }
            //});
        }
    }

    function aktualisiereStorage() {
        // {"i":"check-new-data","last_chats_r":{"1":4,"14":3},"last_users":11}
        // im Grunde kriegt man alle Chats, nur werden die Nachrichten weggelassen die ich schon kenne
        // meinen größten Chat merken, für jeden ChatID kleiner dieser weiß ich, dass es auch bei mir existiert (nicht gleicher Index) -> hashtables, assoziatives array
        if (!(sessionStorage.chatListe && sessionStorage.chatListeHash && sessionStorage.userListe && sessionStorage.userListeHash)) {
            deleteAllStorage();
            ladeAlleInhalte(true); // lädt Daten neu und aktualisiert Oberfläche
            return;
        }
        var chatListe = JSON.parse(sessionStorage.chatListe);
        var chatListeHash = JSON.parse(sessionStorage.chatListeHash);
        var userListe = JSON.parse(sessionStorage.userListe);
        var userListeHash = JSON.parse(sessionStorage.userListeHash);

        var strCheckForNew = '{"i":"check-new-data","closed":'+
          ((sessionStorage.closedView == "1") ? "1" : "0" )+
          ',"admin":'+
          ((sessionStorage.adminView == "1") ? "1" : "0" )+
          ',"last_chats_r":{';

        for (var i=0;i<(Object.keys(chatListe).length);i++) {
            strCheckForNew += '"'+ chatListe[i].id + '":' + getHighestMsgIdForChat(chatListe[i].id) + ',';
        }
        requestCount += 1;
        strCheckForNew = strCheckForNew.slice(0, -1) + '},"last_users":' + getHighestUserId() + ',"reqId" : ' + requestCount + '}'; // ersetzt letztes Komma durch "}"

        callChatctl(strCheckForNew, function(reJson) {
            // neue Daten dem Storage hinzufügen
            //var reJson = JSON.parse(reJsonString);

            // wenn aktuellste Anfrage, verhindert das doppelte Laden von Nachrichten
            if (reJson.reqId != requestCount) {
                return;
            }

            var chatListe = JSON.parse(sessionStorage.chatListe);
            var chatListeHash = JSON.parse(sessionStorage.chatListeHash);
            var userListe = JSON.parse(sessionStorage.userListe);
            var userListeHash = JSON.parse(sessionStorage.userListeHash);
            var neueNachrichtenAktuellerChat = {"messages" : []};

            if(!(reJson.hasOwnProperty('data'))){ // gar keine neuen Daten
                return;
            }
            // Chats
            if(reJson.data.hasOwnProperty('chats')){
                var lenNewChats = Object.keys(reJson.data.chats).length;
                for (var i=0;i<lenNewChats;i++) { // für jeden Chat der bei den neuen Daten ist
                    // checken obs den Chat schon gibt, Nachrichten hinzufügen
                    var reChatId = parseInt(reJson.data.chats[i].id);

                    if (!(chatListeHash.hasOwnProperty(reChatId.toString()))) { // wenn neuer Chat, nicht in Hashliste enthalten
                        chatListe.push(reJson.data.chats[i]);
                    } else { // bereits bekannter Chat
                        // Chat Nachrichten in entsprechenden Chatroom laden
                        var chatIndex = chatListeHash[reChatId];
                        var lenChatMessages = Object.keys(reJson.data.chats[i].messages).length; // Anzahl der neuen Nachrichten in dem Chat
                        for (var a=0;a<lenChatMessages;a++) { // für jede neue Nachricht in dem bekannten Chat
                            chatListe[chatIndex].messages.push(reJson.data.chats[i].messages[a]);
                        }
                        // Neue Chatnachrichten für aktuellen Chat laden
                        if (chatListe[chatIndex].id == sessionStorage.aktuelleChatId) {
                            neueNachrichtenAktuellerChat.chatId = chatListe[chatIndex].id;
                            for (var a=0;a<lenChatMessages;a++) { // für jede neue Nachricht in dem bekannten Chat
                                neueNachrichtenAktuellerChat.messages.push(reJson.data.chats[i].messages[a]);
                            }
                        }
                    }
                }
            }

            // User
            if(reJson.data.hasOwnProperty('users')){
                var lenNewUser = Object.keys(reJson.data.users).length;
                for (var i=0;i<lenNewUser;i++) {
                    userListe.push(reJson.data.users[i]);
                }
            }

            // wenn Chats gelöscht wurden aus der Liste löschen
            if(reJson.data.hasOwnProperty('delete')) {
                var lenDelChats = Object.keys(reJson.data.delete).length;
                var chatListeHash = JSON.parse(sessionStorage.chatListeHash);
                for (var i=0;i<lenDelChats;i++) {
                    var chatIndex = chatListeHash[reJson.data.delete[i]]; // gibt Id des zu löschenden Chats
                    chatListe.splice(chatIndex, 1);
                    // wenn der aktuelle Chat gelöscht wurde
                    if (reJson.data.delete[i] == sessionStorage.aktuelleChatId) { // String Vergleich
                        sessionStorage.aktuelleChatId = getLowestChatId();
                        fillChatroomFenster();
                        fillChatMessagesForId(sessionStorage.aktuelleChatId);
                    }
                }
            }

            // Änderungen dingfest machen
            if(reJson.data.hasOwnProperty('users')){
                sessionStorage.userListe = JSON.stringify(userListe);
            }
            if(reJson.data.hasOwnProperty('chats') || reJson.data.hasOwnProperty('delete')){
                sessionStorage.chatListe = JSON.stringify(chatListe);
                sessionStorage.neueNachrichtenAktuellerChat = JSON.stringify(neueNachrichtenAktuellerChat);
            }

            // Hashlisten neu erstellen
            if(reJson.data.hasOwnProperty('users')){
                var hashUsers = {};
                for(var i=0;i<(Object.keys(userListe).length);i++) {
                    hashUsers[userListe[i].id] = i;
                }
                sessionStorage.userListeHash = JSON.stringify(hashUsers);
            }
            if(reJson.data.hasOwnProperty('chats') || reJson.data.hasOwnProperty('delete')){
                var hashChats = {};
                for(var i=0;i<(Object.keys(chatListe).length);i++) {
                    hashChats[chatListe[i].id] = i;
                }
                sessionStorage.chatListeHash = JSON.stringify(hashChats);
            }

            // Neuladen der Listen etc. triggern
            if(reJson.data.hasOwnProperty('chats') || reJson.data.hasOwnProperty('users') || reJson.data.hasOwnProperty('delete')){
                ladeAlleInhalte(false);
            }
        });

        checkForNewMessages();
    }

    function fillAddUsers() {
      if (sessionStorage.userListe) { // wenns das gibt
          var userJsonString = sessionStorage.userListe;
          var userJson = JSON.parse(userJsonString);
          if(!(sessionStorage.chatListe)) { // wenns keine Chats gibt müssen die Felder nicht gefüllt werden
              return;
          }
          var chatListe = JSON.parse(sessionStorage.chatListe);
          var chatListeHash = JSON.parse(sessionStorage.chatListeHash);

          $('#possibleUsersAdd').html("");
          var selectedChatroomId = currentChatId;
          var chatIndex = chatListeHash[selectedChatroomId];
          for(var i=0;i<(Object.keys(userJson).length);i++) {
              var memberIndex = isMemberInChat(chatListe[chatIndex].members, userJson[i].id);
              if (memberIndex == -1) {
                  innerUserId = userJson[i].id;
                  $("#possibleUsersAdd").append('<div class="row modal-row" value="' + innerUserId + '" onClick="addMemberToChat($(this).attr(\'value\'));">' + getUsernameById(innerUserId) + '</div>');
              }
          }
        }
    }

    function fillDelUsers() {
      if (sessionStorage.userListe) { // wenns das gibt
          var userJsonString = sessionStorage.userListe;
          var userJson = JSON.parse(userJsonString);
          if(!(sessionStorage.chatListe)) { // wenns keine Chats gibt müssen die Felder nicht gefüllt werden
              return;
          }
          var chatListe = JSON.parse(sessionStorage.chatListe);
          var chatListeHash = JSON.parse(sessionStorage.chatListeHash);

          $("#possibleUsersToDel").html(""); // Liste leeren
          var selectedChatroomId = currentChatId;
          var chatIndex = chatListeHash[selectedChatroomId];
          for(var i=0;i<(Object.keys(chatListe[chatIndex].members).length);i++) {
              if (!(chatListe[chatIndex].members[i].user_id == sessionStorage.myUserId)) {
                  innerUserId = chatListe[chatIndex].members[i].user_id;
                  $("#possibleUsersToDel").append('<div class="row modal-row" value="' + innerUserId + '" onClick="delMemberFromChat($(this).attr(\'value\'));">' + getUsernameById(innerUserId) + '</div>');
              }
          }
        }
    }

    function fillChatroomFenster() {
        if (sessionStorage.chatListe) {
            var chatJson = JSON.parse(sessionStorage.chatListe);
            var len = Object.keys(chatJson).length;
        } else {
            var chatJson = "";
            var len = 0;
        }

        // merkt sich die Scrollposition
        var lastScrollPosition =  $("#chatsSideBar").scrollTop();
        $("#chatsSideBar").html(""); // leert den Container mit den Chatnachrichten
        //Start des Table Layouts
        //var appendText = '<table border=2 style="max-height:300px;border:2px solid #000;width:100%;height:20px;"><tbody style="height:auto;max-height:300px;"><tr><td colspan="2"><div id="aktuellerChatName">Kein Chat :c</div><div id="aktuelleMemberListe">Noch keine Freunde?</div></td></tr><tr><td id="chatroomFenster"><div style="height:300px;overflow:auto"><table>';
        var appendText = "";
        for(var i=0;i<len;i++){

            // Um auf die letzte Nachricht zugreifen zu können
            var anzNachrichten = ((Object.keys(chatJson[i].messages).length) - 1);

            // onClick triggert das Laden der Chats!
            //appendText += '<tr class="chatroom" onClick="fillChatMessagesForId(' + chatJson[i].id + ')"><td><div><table><tr><td><div class="chatroomListeName">' + interpretChatTitle(chatJson[i].name,i) + '</div></td><td><div class="chatroomListeUhrzeit">';
            // console.log(i);
            var arrDateTime = formatTimestamp(chatJson[i].messages[anzNachrichten].timestamp); // [0] hat Anzeigewert, Datum wenn älter als einen Tag, sonst Zeit
            if(i == 0) {
              appendText += '<div class="row sideBar-body choosen" onClick="fillChatMessagesForId(' + chatJson[i].id + ');toggleChoosenChat(this);" value="' + chatJson[i].id + '">';
            } else {
              appendText += '<div class="row sideBar-body" onClick="fillChatMessagesForId(' + chatJson[i].id + ');toggleChoosenChat(this);" value="' + chatJson[i].id + '">';
            }
              appendText += '<div class="col-sm-12 col-xs-12 sideBar-main">' +
                '<div class="row">' +
                '<div class="col-sm-8 col-xs-8 sideBar-name">' +
                '<span class="name-meta">' + interpretChatTitle(chatJson[i].name,i) + '</span></div>' +
                '<div class="col-xs-4 col-sm-4 sideBar-time pull-right"><span>' + arrDateTime[0] + '</span></div></div>' +
                '<div class="row">' +
                '<div class="col-xs-10 col-sm-10 sideBar-message">';
            var userNachricht = getUsernameById(chatJson[i].messages[anzNachrichten].user_id) + ': ' + interpretMessage(chatJson[i].messages[anzNachrichten].msg,chatJson[i].id,chatJson[i].messages[anzNachrichten].user_id);
            if (userNachricht.match(/\<img src\=\"https.*(.gif|\.png|\.svg|\.jpg)\"/)) {
              appendText += '<span>' + '[Bild]' + '</span>';
            } else if (userNachricht.match(/https\:\/\/www\.youtube\.com\/embed\//)) {
              appendText += '<span>' + '[YouTube Video]' + '</span>';
            } else if (userNachricht.match(/\<a href\=\"/)) {
              appendText += '<span>' + '[Link]' + '</span>';
            } else if (userNachricht.length > 51) {
                appendText += '<span>' + userNachricht.substring(0,48) + '...' + '</span>';
            } else {
                appendText += '<span>' + userNachricht + '</span>';
            }
            // appendText += '</div><div class="col-xs-2 col-sm-2"><div class="newMessageCounter">' + getNewMessageCountForChatId(chatJson[i].id) +
            // '</div></div></div></div></div>';
            appendText += '</div><div class="col-xs-2 col-sm-2"><div class="newMessageCounter hidden">' +
            '</div></div></div></div></div>';
        }

        $("#chatsSideBar").append(appendText);
        // Wieder an die letzte Position scrollen
        $("#chatsSideBar").scrollTop(lastScrollPosition);

    }

    function checkForNewMessages() {
      var totalMessageCount = 0;
      $.each($(".sideBar-body"), function() {
        var newMessageCount = getNewMessageCountForChatId($(this).attr('value'));
        if (newMessageCount != 0) {
          triggerNewMessage(this, newMessageCount);
          totalMessageCount += newMessageCount;
        } else {
          $(this).find('.newMessageCounter').addClass('hidden');
        }
      });
      changePageTitleForNewMessages(totalMessageCount);
    }

    // Parameter kann als String übergeben werden
    function fillChatMessagesForId(pChatId) {
        sessionStorage.aktuelleChatId = pChatId; // aktuellen Chat merken
        if (!(sessionStorage.chatListe)){ // wenn keine Chats vorhanden sind nichts füllen
            return;
        }
        currentChatId = parseInt(pChatId);

        var chatListeHash = JSON.parse(sessionStorage.chatListeHash);
        var chatListe = JSON.parse(sessionStorage.chatListe);
        var chatIndex = chatListeHash[pChatId];
        var anzMessages = Object.keys(chatListe[chatIndex].messages).length;
        var anzMembers = Object.keys(chatListe[chatIndex].members).length;

        for (var i=0;i<anzMembers;i++) {
            var innerUserId = chatListe[chatIndex].members[i].user_id;
            if (innerUserId == sessionStorage.myUserId) {
                var isAdminInChat = parseInt(chatListe[chatIndex].members[i].is_admin);
                if (isAdminInChat == 1) {
                    sessionStorage.isAktuellerChatAdmin = 1;
                    break; // aus Schleife ausbrechen
                }
            }
            sessionStorage.isAktuellerChatAdmin = 0; // nur ausgeführt wenn Schleife nicht unterbrochen wurde -> nicht Admin
        }

        if(parseInt(sessionStorage.isMeGlobalAdmin)
              || parseInt(sessionStorage.isAktuellerChatAdmin)) {
          $('#addUserBtn').removeClass('hidden');
          $('#banUserBtn').removeClass('hidden');
          $('#archiveChatBtn').removeClass('disabled');
        } else {
          $('#addUserBtn').addClass('hidden');
          $('#banUserBtn').addClass('hidden');
          $('#archiveChatBtn').addClass('disabled');
        }

        animateClosedChatsStatus();
        animateAdminViewBtn();

        // Chatnachrichten laden
        $("#conversation").html(""); // Chatnachrichten leeren
        var appendText = formatChatMessages(pChatId, chatListe[chatIndex].messages);

        // ChatListe neu laden, da das interpretieren in formatChatMessages die Member ändern kann
        chatListe = JSON.parse(sessionStorage.chatListe);

        // Überschrift setzen
        $("#chatName").html(interpretChatTitle(chatListe[chatIndex].name, chatListe[chatIndex].id));
        var stringMemberListe = "(";
        for (var i=0;i<(Object.keys(chatListe[chatIndex].members).length);i++) { // für jeden Member im Chat
            stringMemberListe += getUsernameById(chatListe[chatIndex].members[i].user_id) + ",";
        }
        stringMemberListe = stringMemberListe.slice(0, -1) + ')'; // das letzte Komma entfernen, mit ")" ersetzen
        if (stringMemberListe.length > 1) {
            $("#chatUsers").html(stringMemberListe);
        } else {
            $("#chatUsers").html("(keine Member)");
        }

        $("#conversation").append(appendText);
        $("#conversation").scrollTop($("#conversation")[0].scrollHeight); // nach ganz unten scrollen
        //Frontend: Gelesen Status an Chat senden
        sendReadUntil(currentChatId);
    }

    function appendChatMessagesFromStorage() {
        // erst Überprüfung, ob aktueller Chat noch stimmt
        // falls nicht, aktuelle Nachrichten aus dem Storage löschen und abbrechen
        var aktuelleChatId = sessionStorage.aktuelleChatId;
        var neueNachrichten = JSON.parse(sessionStorage.neueNachrichtenAktuellerChat);
        if (!(neueNachrichten.chatId == aktuelleChatId)) {
            sessionStorage.neueNachrichtenAktuellerChat = {};
            return;
        }
        var appendText = formatChatMessages(aktuelleChatId, neueNachrichten.messages);

        // Überschrift User Liste aktualisieren
        var chatListe = JSON.parse(sessionStorage.chatListe);
        var chatListeHash = JSON.parse(sessionStorage.chatListeHash);
        var chatIndex = chatListeHash[aktuelleChatId];
        var stringMemberListe = "(";
        for (var i=0;i<(Object.keys(chatListe[chatIndex].members).length);i++) { // für jeden Member im Chat
            stringMemberListe += getUsernameById(chatListe[chatIndex].members[i].user_id) + ",";
        }
        var stringMemberListe = stringMemberListe.slice(0, -1) + ')'; // das letzte Komma entfernen, mit ")" ersetzen
        $("#chatUsers").html(stringMemberListe);

        var boolScrollen = false;

        // Nur Scrollen wenn er in der Nähe des unteren Rands ist (fast ganz nach unten gescrollt)
        var divConversation = $("#conversation");

        if (divConversation[0].scrollHeight - divConversation.scrollTop() == divConversation.outerHeight()) {
            boolScrollen = true;
        }

        divConversation.append(appendText);
        sendReadUntil(sessionStorage.aktuelleChatId); // Sorgt dafür, dass der read status im aktuellen chat immer ganz unten ist --> keine Benachrichtigung
        // Wenn fast ganz unten, nach ganz unten scrollen
        if (boolScrollen) {
            divConversation.scrollTop(divConversation[0].scrollHeight); // nach ganz unten scrollen
        }
    }

    // Iteriert über übergebenen messages Array und gibt in HTML formatierten String zurück
    function formatChatMessages(chatId, messages) {
        var anzMessages = Object.keys(messages).length;
        var appendText = "";
        for (var i=0;i<anzMessages;i++) { // für jede Nachricht
            // Unterscheidung ob von einem selbst oder von wem anders
            // Zuerst Timestamp in Array formatieren
            var arrDateTime = formatTimestamp(messages[i].timestamp);
            if(messages[i].user_id == sessionStorage.myUserId) {
                appendText += '<div class="row message-body">' +
  	            '<div class="col-sm-12 message-main-sender">' +
  	            '<div class="sender">' +
      		      '<div class="message-text">' +
      		            interpretMessage(messages[i].msg, chatId,messages[i].user_id) +
      		      '</div><a class="message-time pull-right" data-toggle="tooltip" data-placement="left" title="' + arrDateTime[1] + '">' +
      		            arrDateTime[0] +
      		      '</a></div></div></div>';
            } else if(messages[i].user_id == 0) { // Systemnachricht
              appendText += '<div class="row message-body">' +
                '<div class="col-sm-12 message-main-system">' +
                '<div class="system">' +
                '<div class="message-text">' + interpretMessage(messages[i].msg, chatId,messages[i].user_id) + '</div></div></div></div>';
            } else {
                appendText += '<div class="row message-body">' +
                '<div class="col-sm-12 message-main-receiver">' +//<!-- Hier anpassen -->
    	          '<div class="receiver">' +//<!-- Hier anpassen -->
                '<div class="message-name">' +
                      getUsernameById(messages[i].user_id) +
                '</div>' +
      		      '<div class="message-text">' +
      		            interpretMessage(messages[i].msg, chatId, messages[i].user_id) +
      		      '</div><a class="message-time pull-right" data-toggle="tooltip" data-placement="right" title="' + arrDateTime[1] + '">' +
      		            arrDateTime[0] +
      		      '</a></div></div></div>';
            }
        }
        return appendText;
    }

    function sendReadUntil(chat_id){
        var hoechsteChatId = getHighestMsgIdForChat(chat_id);
        callChatctl('{"i":"read-until","chat_id":' + chat_id + ',"last_msg":' + hoechsteChatId + '}', function(){});
        if (!sessionStorage.chatListe) {
            return;
        }

        var chatListe = JSON.parse(sessionStorage.chatListe);
        var chatListeHash = JSON.parse(sessionStorage.chatListeHash);
        chatListe[chatListeHash[chat_id]].read_until = hoechsteChatId;

        // nur chatListe muss gespeichert werden
        sessionStorage.chatListe = JSON.stringify(chatListe);
    }

    function fillChatroomSelect() {

        if (sessionStorage.chatListe) { // wenns das gibt
            var chatJsonString = sessionStorage.chatListe;
            var chatJson = JSON.parse(chatJsonString);
            $("#selectChatroomToAdd").html(""); // Inhalt leeren
            $("#selectChatroomToDel").html(""); // Inhalt leeren
            for(var i=0;i<(Object.keys(chatJson).length);i++) {
                $("#selectChatroomToAdd").append(new Option(chatJson[i].name, chatJson[i].id));
                $("#selectChatroomToDel").append(new Option(chatJson[i].name, chatJson[i].id));
            }
        }
    }

    function fillSelectUserForChatroom() {
        if (sessionStorage.userListe) { // wenns das gibt
            var userJsonString = sessionStorage.userListe;
            var userJson = JSON.parse(userJsonString);
            $("#newChatUsers").html(""); // leeren
            var appendText = '';
            for(var i=0;i<(Object.keys(userJson).length);i++) {
                if (!(userJson[i].id == sessionStorage.myUserId)) {
                    //$("#selectUserForChatroom").append(new Option(userJson[i].name, userJson[i].id));
                    appendText += '<div class="row modal-row modal-row-newChat" onClick="toggleSelectRow(this);">'+
                                  '<div class="col-xs-6 col-sm-8">'+
                                    userJson[i].name +
                                  '</div>'+
                                  '<div class="col-xs-6 col-sm-4">'+
                                  '<input type="checkbox" class="checkbox hidden" name="userCheckbox" value="' + userJson[i].id + '" readonly="readonly">'+ // userID
                                  '</div></div>';
                }
            }
            $("#newChatUsers").append(appendText);
        }
    }

    function createNewChat() {
      var selectedUsers = [];

      $('#newChatUsers input:checked').each(function() {
        selectedUsers.push(parseInt($(this).attr('value')));
      });
      var newChatName = $('#inputNewChatroomName').val();
      if(selectedUsers.length !== 0 && newChatName !== "" && newChatName.length <= 32){
        createChatroom(newChatName,selectedUsers);
        $('#inputNewChatroomName').val("");
        $('#newChatModal').modal('toggle');
      } else {
        $('#newChatModal').animateCss('shake');
      }
    }

    function sendChatMsg() {
        var chatText = $("#inputChatMessage").val();
        var chatroomId = parseInt(sessionStorage.aktuelleChatId);
        if (chatText.length === 0 || !chatText.trim()) { // wenn der String leer ist, oder nur Blanks enthält
            console.log("Es wurde versucht einen leeren Chat zu schicken an: " + getChatnameById(chatroomId));
            $("#inputChatMessage").val("");
            $("#inputChatMessage").focus();
        } else {
            //console.log("Chat wurde geschrieben an: (" + chatroomId + ") - " + chatText);
            chatText = chatText.replace(/\\/g,"\\\\"); // jeden Backslash escapen, /string/g ersetzt jede Erscheinung von string, sonst nur erste
            chatText = chatText.replace(/\"/g,"\\\""); // jedes Anführungszeichen escapen
            var jsonSend = '{"i":"send-message","chat_id":'+chatroomId+',"msg":"'+chatText+'"}';//{"i":"send-message","chat_id":"14","msg":"Erste Nachricht die Automatisch erstellt wurde!"}
            callChatctl(jsonSend, function() {});
            $("#inputChatMessage").val(""); // löscht den Text aus dem Textfeld
            $("#inputChatMessage").focus();
        }

        //sendReadUntil(sessionStorage.aktuelleChatId);
    }

    function createChatroom(chatName, userIdArray){
        console.log("Neuer Chatroom Name: " + chatName);
        console.log("Mit " + userIdArray);
        // {"i":"create-chat","name":"AutoGeneratedChat","members":[10,11,12]}
        var jsonString = '{"i":"create-chat","name":"'+chatName+'","members":['+userIdArray.toString()+']}';
        callChatctl(jsonString, function() {});
    }

    function addMemberToChat(submittedUserId) {
        //{"i":"add-group-member","chat_id":1,"user":12}
        var userId = parseInt(submittedUserId);
        var chatId = currentChatId;
        var sendString = '{"i":"add-group-member","chat_id":"' + chatId + '", "user":"' + userId +'"}';
        callChatctl(sendString, function(){});
        $('#addUserModal').modal('toggle');
        // fillAddUsers();
    }

    function delMemberFromChat(submittedUserId) {
        //{"i":"add-group-member","chat_id":1,"user":12}
        var userId = parseInt(submittedUserId);
        var chatId = currentChatId;
        var sendString = '{"i":"del-group-member","chat_id":"' + chatId + '", "user":"' + userId +'"}';
        callChatctl(sendString, function(){});
        $('#banUserModal').modal('toggle');
        // fillDelUsers();
    }

    function leaveCurrentChat() {
        var userId = sessionStorage.myUserId;
        var chatId = currentChatId;
        var sendString = '{"i":"del-group-member","chat_id":"' + chatId + '", "user":"' + userId +'"}';
        callChatctl(sendString, function(){});
    }

    function startRandomChat() {
        var sendString = '{"i":"request-random-chat"}';
        callChatctl(sendString, function(){});
    }

    function closeChat() {
        var chatId = currentChatId;
        var sendString = '{"i":"close-chat","chat_id":"' + chatId + '"}';
        callChatctl(sendString, function(){});
    }

    function switchClosedChats() {
        if(!sessionStorage.closedView || sessionStorage.closedView == "0") {
          deleteAllStorage();
          clearInterval(intervalId);
          sessionStorage.closedView = "1";
          ladeAlleInhalte(true);
        } else {
          deleteAllStorage();
          intervalId = setInterval(function(){ aktualisiereStorage(); }, 1000);
          sessionStorage.closedView = "0";
          ladeAlleInhalte(true);
        }

        animateClosedChatsStatus();
    }


    function toggleAdminView() {
      if(!sessionStorage.adminView || sessionStorage.adminView == "0") {
        deleteAllStorage();
        sessionStorage.adminView = "1";
        ladeAlleInhalte(true);
      } else {
        deleteAllStorage();
        sessionStorage.adminView = "0";
        ladeAlleInhalte(true);
      }
      animateAdminViewBtn();
    }


    function interpretMessage(messageString, chatId,senderId) {
        if(parseInt(senderId) != 0) {
          var media_r = messageString.match(/^https?\:\/\/.*(.gif|\.png|\.svg|\.jpg)/);
          if(media_r) {
            media_r[0] = media_r[0].replace("http\:\/\/","https\:\/\/");
            restStr = messageString.replace(/^https\:\/\/\S+(.gif|\.png|\.svg|\.jpg)\s(.*)/,'$2');
            messageString = '<a href=\"'+ media_r[0]+ '\" target=\"_blank"\"><img src="'+ media_r[0]+ '" alt=\"Bild\" width=\"100%\"></a><br>'+ restStr;
            return messageString;
          }
          var media_r = messageString.match(/^https?.*youtube\.com\/watch\?v\=.*( |$)/);
          if(media_r) {
            media_r[0] = media_r[0].replace("http\:\/\/","https\:\/\/");
            media_r[0] = media_r[0].replace(/https\:\/\/www\.youtube\.com\/watch\?v\=(\S+)( |$)/,'$1');
            restStr = messageString.replace(/^https\:\/\/www\.youtube\.com\/watch\?v\=\S+\s(.*)/,'$1');
            messageString = '<iframe width="100%" src="https://www.youtube.com/embed/'+ media_r[0]+ '"> </iframe><br>'+ restStr;
            return messageString;
          }
          var media_r = messageString.match(/^https?\:\/\/\S+/);
          if(media_r) {
            media_r[0] = media_r[0].replace("http\:\/\/","https\:\/\/");
            restStr = messageString.replace(/^https?\:\/\/\S+\s(.*)/,'$1');
            messageString = '<a href=\"'+ media_r[0]+ '\" target=\"_blank"\">'+ media_r[0]+ '</a><br>'+ restStr;
            return messageString;
          }
        }

        switch (messageString.split(" ")[0]) { //nur das erste Wort prüfen
            case "add_group_member":
                var userId1 = messageString.split(" ")[1];
                var userName1 = getUsernameById(userId1);
                var userId2 = messageString.split(" ")[2];
                var userName2 = getUsernameById(userId2);
                var chatListe = JSON.parse(sessionStorage.chatListe);
                var chatListeHash = JSON.parse(sessionStorage.chatListeHash);
                var chatIndex = chatListeHash[chatId];
                var memberIndex = isMemberInChat(chatListe[chatIndex].members, userId2);
                if(memberIndex == -1) { // member noch nicht vorhanden
                    chatListe[chatIndex].members.push({"user_id" : userId2});
                    sessionStorage.chatListe = JSON.stringify(chatListe);
                }
                // wenn er sich selbst hinzugefügt hat (globaler Admin)
                if(userId1 == userId2) {
                    return (userName1 + " ist der Gruppe mutig und allein beigetreten.");
                }
                return (userName1 + " hat die Gruppe mit " + userName2 + " bereichert.");
                break;
            case "del_group_member":
                var userId1 = messageString.split(" ")[1];
                var userName1 = getUsernameById(userId1);
                var userId2 = messageString.split(" ")[2];
                var userName2 = getUsernameById(userId2);

                var chatListe = JSON.parse(sessionStorage.chatListe);
                var chatListeHash = JSON.parse(sessionStorage.chatListeHash);
                var chatIndex = chatListeHash[chatId];
                var memberIndex = isMemberInChat(chatListe[chatIndex].members, userId2);
                if (memberIndex != -1) { // member ist vorhanden
                    chatListe[chatIndex].members.splice(memberIndex, 1);
                    sessionStorage.chatListe = JSON.stringify(chatListe);
                }
                // wenn der User die Gruppe verlassen hat / sich selbst rausgeschmissen hat
                if (userId1 == userId2) {
                    return (userName1 + " hat die Gruppe verlassen.");
                }
                return (userName1 + " hat " + userName2 + " aus dem Chat verbannt.");
                break;
            case "group_admin":
                var userName1 = getUsernameById(messageString.split(" ")[2]);
                var userName2 = getUsernameById(messageString.split(" ")[3]);
                if ((messageString.split(" ")[1]) == "1") {
                    return (userName1 + " hat " + userName2 + " zum Chat Admin gemacht.");
                } else {
                    return (userName1 + " hat " + userName2 + " seine Rechte entzogen.");
                }
                break;
            case "create_new_chat":
                var username1 = getUsernameById(messageString.split(" ")[1]);
                var chatListe = JSON.parse(sessionStorage.chatListe);
                var chatListeHash = JSON.parse(sessionStorage.chatListeHash);
                var chatIndex = chatListeHash[chatId];
                return (username1+" hat den Chat \""+ chatListe[chatIndex].name +"\" erstellt.");
                break;
            case "create_random_chat":
                var userName1 = getUsernameById(messageString.split(" ")[1]);
                var userName2 = getUsernameById(messageString.split(" ")[2]);
                var chatListe = JSON.parse(sessionStorage.chatListe);
                var chatListeHash = JSON.parse(sessionStorage.chatListeHash);
                var chatIndex = chatListeHash[chatId];
                return (userName1+ " hat einen zufälligen Chat gestartet und "+ userName2+ " ist sein Chatpartner.");
                break;
            case "chat_closed":
                var userName1 = getUsernameById(messageString.split(" ")[1]);
                return ("Der Chat wurde von "+ userName1+ " geschlossen.");
                break;
            default:
                return messageString;
        }
    }

    function interpretChatTitle(messageString, chatId) {
        switch (messageString.split(" ")[0]) { //nur das erste Wort prüfen
            case "random":
                var userId1   = messageString.split(" ")[2];
                var userName1 = getUsernameById(userId1);
                var userId2   = messageString.split(" ")[3];
                var userName2 = getUsernameById(userId2);
                var userId = sessionStorage.myUserId;

                var strangerName = userName1;
                if(userId1 == userId) strangerName = userName2;

                return ("Zufälliger Chat mit "+ strangerName);
                break;
            default:
                return messageString;
        }
    }

    // Gibt Array zurück, in [0] das was angezeigt werden soll, [1] das für Popup <-- tooltip
    function formatTimestamp(inpTimestamp) {
        var inpFormatTimestamp = (inpTimestamp.split(" ")[0] + "T" + inpTimestamp.split(" ")[1] + "Z");
        var timestampDate = new Date(inpFormatTimestamp);
        var dayAgoDate = new Date(); // beinhaltet aktuelles Datum + Zeit
        dayAgoDate.setDate(dayAgoDate.getDate()-1); // einen Tag abziehen
        // Dreht Datum um: "2017-06-19" -> "19.06.2017"
        var inpStrNurDatum = ((inpTimestamp.split(" ")[0]).split("-")[2] + "." + (inpTimestamp.split(" ")[0]).split("-")[1] + "." + (inpTimestamp.split(" ")[0]).split("-")[0]);
        var retArray = new Array();

        if (timestampDate > dayAgoDate) { // wenn innerhalb der letzten 24 Stunden
            retArray[0] = inpTimestamp.split(" ")[1]; // Zeit
            retArray[1] = inpStrNurDatum; // Datum
        } else {
            retArray[0] = inpStrNurDatum; // Datum
            retArray[1] = inpTimestamp.split(" ")[1]; // Zeit
        }
        return retArray;
    }

    function isMemberInChat(pMemberArray, pUserId) { // userId als String übergeben!
        for (var i=0;i<Object.keys(pMemberArray).length;i++) {
            if(pMemberArray[i].user_id == pUserId) {
                return i;
            }
        }
        return -1;
    }

    function getUsernameById(userId) {
        if (sessionStorage.userListe) { // wenns das gibt
            var userJsonString = sessionStorage.userListe;
            var userJson = JSON.parse(userJsonString);
            if (userId == 0) {return "System"}; // Systemnachricht
            for(var i=0;i<(Object.keys(userJson).length);i++) {
                if(userJson[i].id == userId) {
                    return userJson[i].name;
                }
            }
        }
    }

    function getChatnameById(chatId) {
        if (sessionStorage.chatListe) { // wenns das gibt
            var chatJsonString = sessionStorage.chatListe;
            var chatJson = JSON.parse(chatJsonString);
            for(var i=0;i<(Object.keys(chatJson).length);i++) {
                if(chatJson[i].id == chatId) {
                    return chatJson[i].name;
                }
            }
        }
    }

    function getHighestMsgIdForChat(chatId) {
        var chatsHash = JSON.parse(sessionStorage.chatListeHash);
        var chatIndex = chatsHash[parseInt(chatId)];
        var chatListe = JSON.parse(sessionStorage.chatListe);
        var retChatId = -1;
        var lenMessages = Object.keys(chatListe[chatIndex].messages).length;  //Anzahl der Nachrichten im Chat
        if(!(chatListe[chatIndex].messages[lenMessages-1].hasOwnProperty('id'))){ // Chatroom hat noch keine Nachricht
            return 0; // keine Nachricht -> höchste Id = 0
        }
        retChatId = chatListe[chatIndex].messages[lenMessages-1].id; // Länge - 1 weil Array bei 0 beginnt
        return retChatId;
    }

    function getHighestUserId() {
        var userListe = JSON.parse(sessionStorage.userListe);
        var retUserId = -1;
        var lenUsers = Object.keys(userListe).length;
        retUserId = userListe[lenUsers-1].id; // Länge - 1 weil Array bei 0 beginnt
        return retUserId;
    }

    function getHighestChatId() {
        if (!(sessionStorage.chatListe)) {
            return -1;
        }
        var chatListe = JSON.parse(sessionStorage.chatListe);
        var retChatId = -1;
        var lenChats = Object.keys(chatListe).length;
        retChatId = chatListe[lenChats-1].id; // Länge - 1 weil Array bei 0 beginnt
        return retChatId;
    }

    function getLowestChatId() {
        if (!(sessionStorage.chatListe)) {
            return -1;
        }
        var chatListe = JSON.parse(sessionStorage.chatListe);
        var retChatId = -1;
        retChatId = chatListe[0].id; // Länge - 1 weil Array bei 0 beginnt
        return retChatId;
    }

    function getNewMessageCountForChatId(chatId) {
        var chatListe = JSON.parse(sessionStorage.chatListe);
        var chatListeHash = JSON.parse(sessionStorage.chatListeHash);
        var chatIndex = chatListeHash[chatId];
        var readUntilChatId = chatListe[chatIndex].read_until; // String!
        var messageIndex = Object.keys(chatListe[chatIndex].messages).length - 1;
        //var highestChatId = getHighestMsgIdForChat(chatId);
        var retNewCount = 0;
        // messageIndex zählt von oben runter, geht array von oben durch und zählt bis readUntil ID erreicht ist
        while(chatListe[chatIndex].messages[messageIndex].id != readUntilChatId) {
            retNewCount += 1;
            if (messageIndex == 0) {
                break;
            }
            messageIndex -= 1;
        }
        return retNewCount;
    }

    // setzt die globale Variable, kann genutzt werden um die Suche zu aktualisieren
    function formChange(id) {
        selected.chatId = id;
    }

    function deleteAllStorage() {
        if (sessionStorage.userListe) {sessionStorage.removeItem("userListe");}
        if (sessionStorage.userListeHash) {sessionStorage.removeItem("userListeHash");}
        if (sessionStorage.chatListe) {sessionStorage.removeItem("chatListe");}
        if (sessionStorage.chatListeHash) {sessionStorage.removeItem("chatListeHash");}
        if (sessionStorage.myUserId) {sessionStorage.removeItem("myUserId");}
        //if (sessionStorage.closedView) {sessionStorage.removeItem("closedView");}
    }

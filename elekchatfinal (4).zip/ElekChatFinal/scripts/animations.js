var adminViewIsOpen = false;
var mobileMenuIsOpen = false;
var mobileNavIsOpen = false;
var newChatNameInputTooLong = false;

$(document).ready(function() {
  $('body').tooltip({
    selector: '[data-toggle="tooltip"]'
  });
  $('.error-tooltip').tooltip({trigger: 'manual'});

  $('.message').scrollTop($('.message')[0].scrollHeight);

  if( /Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent) ) {
    $('.side').swipe({
      swipeLeft:function(event, direction, distance, duration, fingerCount) {
        mobileNavIsOpen = true;
        toggleMobileNav();
      }
    });

    $(".conversation").swipe({
      swipeRight:function(event, direction, distance, duration, fingerCount) {
        mobileNavIsOpen = false;
        toggleMobileNav();
      }
    });
  }

  if ($(window).width() <= 768){
    $('.side').fadeOut();
    $('.mobile-menu-btn').hide();
    $('#mobileMenuBtn').removeClass('hidden');
  }

  $('.loadingScreen').delay(800).fadeOut('slow');
  // $('.loadingScreen').delay(800).hide('slow');

  $('#mobileMenuBtn').click(function() {
    toggleMobileMenu();
  });

  $('.mobile-menu-chatname').click(function() {
    if ($(window).width() <= 768) {
      toggleMobileNav();
    }
  });

  $('#conversation').dblclick(function() {
    toggleFullScreen();
  });

  $('#inputNewChatroomName').on('keyup',function (){
    checkInputLenght(this);
  });
});


$(window).resize(function(){
	if ($(window).width() <= 768){
    $('.side').fadeOut();
    $('.mobile-menu-btn').fadeOut();
    $('#mobileMenuBtn').removeClass('hidden');
	}
  if ($(window).width() > 768){
    $('#mobileMenuBtn').addClass('hidden');
    $('.mobile-menu-btn').fadeIn();
    $('.side').show();
    $('.conversation').show();
    // toggleMobileMenu();
  }
});

$.fn.extend({
    animateCss: function (animationName) {
        var animationEnd = 'webkitAnimationEnd mozAnimationEnd MSAnimationEnd oanimationend animationend';
        this.addClass('animated ' + animationName).one(animationEnd, function () {
            $(this).removeClass('animated ' + animationName);
        });
    }
});

function checkInputLenght(div) {
  var userInputLength = $(div).val().length;
  if (userInputLength > 32) {
    if (newChatNameInputTooLong == false) {
      $('.error-tooltip').tooltip('show');
      $(div).css('background-color','#ff9999');
      $('#submitNewChatBtn').attr('disabled','true');
      newChatNameInputTooLong = true;
    }
  }
  if (userInputLength <= 32) {
    // $('.error-tooltip').tooltip('dispose');
    $('.error-tooltip').tooltip('hide');
    $(div).css('background-color','#ffffff');
    $('#submitNewChatBtn').removeAttr('disabled');
    newChatNameInputTooLong = false;
  }
}

function triggerNewMessage(div, messageCount) {
  var messageCountDiv = $(div).find('.newMessageCounter');
  messageCountDiv.removeClass('hidden');
  if (messageCount >= 100) {
    messageCountDiv.width(40);
  }
  messageCountDiv.html(messageCount);
  messageCountDiv.animateCss('rubberBand');
}

function changePageTitleForNewMessages(totalMessageCount) {
  if (totalMessageCount != 0) {
    if (totalMessageCount == 1) {
      $(document).prop('title','Neue Nachricht');
    } else {
      $(document).prop('title','(' + totalMessageCount + ') Neue Nachrichten');
    }
  } else {
    var currentTitle = $(document).prop('title');
    if (currentTitle != "ElekChat") {
      $(document).prop('title','ElekChat');
    }
  }
}

function animateAdminViewBtn() {
    var avcolor;
    if(sessionStorage.adminView == "1") avcolor = '#4daaaa';
    else avcolor = '#4d4d4d';

    $('#adminView').css('color',avcolor);
}

function animateClosedChatsStatus() {
    var btn = $('#showArchivedChatsBtn');
    var cccolor;

    if(sessionStorage.closedView == "1") {
      btn.text("Aktuelle Chats anzeigen");
      cccolor = '#4daaaa';
    } else {
      btn.text("Archivierte Chats anzeigen");
      cccolor = '#4d4d4d';
    }

    $('#archiveChatMenuBtn').css('color',cccolor);
}

function toggleMobileMenu() {
  if(mobileMenuIsOpen) {
    $('.mobile-menu-btn').hide();
    $('.mobile-menu-chatname').show();
    mobileMenuIsOpen = false;
  } else {
    $('.mobile-menu-chatname').hide();
    $('.mobile-menu-btn').show();
    mobileMenuIsOpen = true;
  }
}

function toggleMobileNav() {
  if(mobileNavIsOpen) {
    $('.side').hide();
    $('.conversation').show();
    mobileNavIsOpen = false;
  } else {
    $('.conversation').hide();
    $('.side').show();
    mobileNavIsOpen = true;
  }
}

function toggleSelectRow(selectedDiv) {
    var row = $(selectedDiv).find('.checkbox');
    $(selectedDiv).toggleClass("choosen");
    if (row.prop('checked') == true) {
      row.prop('checked', false);
    } else {
      row.prop('checked', true);
    }
}

function toggleChoosenChat(div) {
  $('.row .sideBar-body').removeClass('choosen');
  $(div).addClass('choosen');
  if($(window).width() <= 768) {
    toggleMobileNav();
  }
}

function toggleFullScreen() {
  var doc = window.document;
  var docEl = doc.documentElement;

  var requestFullScreen = docEl.requestFullscreen || docEl.mozRequestFullScreen || docEl.webkitRequestFullScreen || docEl.msRequestFullscreen;
  var cancelFullScreen = doc.exitFullscreen || doc.mozCancelFullScreen || doc.webkitExitFullscreen || doc.msExitFullscreen;

  if(!doc.fullscreenElement && !doc.mozFullScreenElement && !doc.webkitFullscreenElement && !doc.msFullscreenElement) {
    requestFullScreen.call(docEl);
  }
  else {
    cancelFullScreen.call(doc);
  }
}

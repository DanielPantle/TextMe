<?php
ini_set('session.gc_maxlifetime', 604800);
session_set_cookie_params(604800);
session_start();
include 'backend/register_functions.php';
include 'backend/lib_chatctl.php';

//forwards to chat if the user has a session and is logged in
if(isset($_SESSION['user_id'])){
  header("Location: /index.php");
}
//unauthenticated user will see the registration form
else{
  //echo "Registrierung";
  //echo "<br><hr><br>";
  //if the $_POST variables from the form are set it will try to create the user
  if(isset($_POST["username"]) && isset($_POST["passwd"])){

    // checks if the $_POST variables have values
    if($_POST["username"] != "" && $_POST["passwd"] != ""){
      $username = $_POST["username"];

      //Checks if there are < or > or /, if so the username will not be accepted
      $username_escape = xss_prevent($username);
      if($username != $username_escape){
        header("Location: register.php?error=xss");
        die;
      }

      echo $username;
      echo $username_escape;


      $pwd = $_POST["passwd"];
      $pwd = password_hash($pwd, PASSWORD_BCRYPT);

      if ( preg_match('/\s/',$username) ){
        header("Location: register.php?error=whitespace");
      }
      else{
        if(check_username_available($_POST["username"])){
          create_user($username, $pwd);
          header("Location: login.php?login=created");
        }
        //if username is taken, set error
        else{
          header("Location: register.php?error=taken");
        }
      }
    }
    //if username or passwd values were empty this notifies the users
    else{
      header("Location: register.php?error=missing");
    }
  }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
  <title>ElekChat Registration</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <link rel="stylesheet" href="styles/animate.css">
  <link rel="stylesheet" href="styles/ln_styles.css">
  <style>
  .passwd-false:not(:focus) {
    background-color: red;
  }
  .passwd-false:focus {
    /*background-color: #ff8080;*/
    border-color: red;
    box-shadow: red;
  }
  .passwd-correct:not(:focus) {

  }
  .passwd-correct:focus {

  }
  </style>
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
  <script src="scripts/animations.js"></script>
  <script type="text/javascript">
  // Animations can be used like $('ID or Classname').animateCss('Animationname');
  // For more detailed informations check: https://daneden.github.io/animate.css/

  $(document).ready(function () {
    // Checks for keyCodes 6 [Backspace] and 46 [delete]
    // makes sure a username is set
    $('html').keyup(function(e){
      if(e.keyCode == 8 || e.keyCode == 46) {
        if(document.getElementById("inputUsername").value === "") {
          document.getElementById("registerButton").classList.add('disabled');
          document.getElementById("registerButton").disabled = true;
        }
      }
    });
  });

  // Validate the two password inputs on keyUp event and the username field
  function validate() {
    if(document.getElementById("inputConfirmPassword").value !== document.getElementById("inputPassword").value){
      document.getElementById("inputConfirmPassword").classList.add('passwd-false');
      document.getElementById("inputPassword").classList.add('passwd-false');
      document.getElementById("registerButton").classList.add('disabled');
      document.getElementById("registerButton").disabled = true;
    }else{
      if (document.getElementById("inputConfirmPassword").value !== ""
      && document.getElementById("inputPassword").value !== "") {
        document.getElementById("inputConfirmPassword").classList.remove('passwd-false');
        document.getElementById("inputPassword").classList.remove('passwd-false');
        // Check if username is not empty
        if(document.getElementById("inputUsername").value !== "") {
          document.getElementById("registerButton").classList.remove('disabled');
          document.getElementById("registerButton").disabled = false;
        }
      }
    }
  }

  </script>
</head>
<body>

  <!-- Login Popup -->
  <!-- Modal content -->
  <div class="modal-content">
    <div class="modal-header">
      <h2>Registrierung</h2>
      <?php if($_GET['error'] === 'missing') {
        echo '<span><font color="red">Bitte alle Felder ausfüllen!</font></span>';
      } elseif ($_GET['error'] === 'taken') {
        echo '<span><font color="orange">Benutzername bereits belegt</font></span>';
      } elseif ($_GET['error'] === 'whitespace') {
        echo '<span><font color="red">Benutzername darf keine Leerzeichen enthalten</font></span>';
      } elseif ($_GET['error'] === 'xss') {
        echo '<span><font color="red">Du scheiss Script-Kiddie</font></span>';
      }
      ?>
    </div>
    <div class="modal-body">
      <form id="RegisterForm" action="register.php" method="post">
        <div class="form-group">
          <input type="text" class="form-control top-space" id="inputUsername" onKeyUp="validate();" placeholder="Benutzername" name="username"/>
          <br/>
          <input type="password" class="form-control top-space" id="inputPassword" onKeyUp="validate();" placeholder="Passwort" name="passwd"/>
          <input type="password" class="form-control top-space" id="inputConfirmPassword" onKeyUp="validate();" placeholder="Passwort bestätigen" name="passwdconfirm"/>
          <button type="submit" class="btn btn-default top-space disabled btn-lnreg" id="registerButton" disabled="true">Abschicken</button>
        </div>
      </form>
    </div>
    <div class="modal-footer">
      <a id="linkLogin" href="login.php"><h4>zum Login</h4></a>
    </div>
  </div>

</body>

</html>

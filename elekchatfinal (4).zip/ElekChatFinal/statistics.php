<?php
ini_set('session.gc_maxlifetime', 604800);
session_set_cookie_params(604800);
session_start();
include 'backend/statistic_functions.php';

//Prüft ob eine eingeloggte Session vorhanden ist, wenn nein wird auf die Loginseite umgeleitet
if(!isset($_SESSION['user_id'])){
  header("Location: login.php");
}

if(!$_SESSION['is_global_admin']){
  header("Location: login.php");
}

if($_SESSION['is_global_admin']){
  $oneHour = '<br>Gesendete Nachrichten in der letzten Stunde: ' . msg_count_per_time(1);
  $twentyfourHour = '<br>Gesendete Nachrichten in den letzten 24 Stunden: ' . msg_count_per_time(24);
  $registeredUsers = '<br>Registrierte Benutzer: ' . user_count();
  $totalMessages = '<br>Nachrichten insgesamt versendet: ' . total_chat_messages();
  $recentlyActive = '<br>Aktive Nutzer in den letzten 5 Minuten: ' . recently_active();
  $onlineUsers = '<br>Nutzer online: ' . online_users();
}

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <title>ElekChat Statistiken</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
    <link rel="stylesheet" href="styles/animate.css">
    <link rel="stylesheet" href="styles/ln_styles.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
    <script src="animations.js"></script>
    <script type="scripts/text/javascript">
        var $_GET = {};

        // Executed when document has fully loaded
        $(document).ready( function() {
          // Puts GET parameters into a javascript object named $_GET
          document.location.search.replace(/\??(?:([^=]+)=([^&]*)&?)/g, function () {
            function decode(s) {
              return decodeURIComponent(s.split("+").join(" "));
            }
          $_GET[decode(arguments[1])] = decode(arguments[2]);
          });

          // Animates stuff based on GET parameters
          if($_GET.login === "false") {
              shakeLogin();
          }
        });

        // Animation
        // Animations can be used like $('ID or Classname').animateCss('Animationname');
        // For more detailed informations check: https://daneden.github.io/animate.css/

        // Shake Login Form on wrong password
        function shakeLogin() {
            $('#LoginForm').animateCss('shake');
        }
        // reload every 5s
        //setTimeout(function(){window.location.reload(1);}, 5000);
    </script>
</head>

<body>

    <!-- Login Popup -->
    <!-- Modal content -->
    <div class="modal-content" style="top:0;">
        <div class="modal-header">
            <h2>Statistik</h2>
        </div>
        <div class="modal-body">
            <form id="LoginForm" action="login.php" method="post">
              <div class="form-group" id="statisticContent">
                <?php
                echo $oneHour;
                echo $twentyfourHour;
                echo $registeredUsers;
                //echo $totalMessages;
                //echo $recentlyActive;
                //echo $onlineUsers;
                 ?>
              </div>
            </form>
            <iframe src="https://guest:124365@stats.farene.de/dashboard-solo/db/elektroprufung?panelId=1&theme=dark" width="100%" height="200" frameborder="0"></iframe>
            <iframe src="https://guest:124365@stats.farene.de/dashboard-solo/db/elektroprufung?panelId=2&theme=dark" width="100%" height="200" frameborder="0"></iframe>
        </div>
        <div class="modal-footer">
            <h4><a id="toChat" href="../index.php">zum Chat</a> // <span style = "display: inline;"><a id="toLogout" href="../logout.php">Logout</a></span></h4>
        </div>
    </div>

</body>

</html>

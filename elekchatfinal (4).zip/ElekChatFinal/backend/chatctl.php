<?php session_start();
// Name:        chatctl.php
// Author:      Rene Fa
// Date:        14.06.2017
// Version:     1.2
//
// Description:
//  Dieses Programm soll das Backend für die Chats darstellen.
//  Es können hier die Chats, User und Gruppen abgerufen werden.
//  Alle Daten werden im JSON Format zurück gegeben.

//Enthält alle Befehle für das Backend
include "lib_chatctl.php";

$return_array = array();

//Prüft ob der bereits ein Status gesetzt wurde
function done(){
  global $return_array;
  
  if(isset($return_array) and isset($return_array['status'])) return 1;
  else return 0;
}

//Prüft auf Authorisierung
if(!isset($_SESSION['user_id'])) {
    $return_array['status'] = "unauthorized";
    $return_array['status_log'] = "Du bist nicht angemeldet oder die Session ist abgelaufen.";
}

//Liest die JSON Daten als ganzes ein und speichert sie in einem assoziativen Array
$rawpostdata = file_get_contents("php://input");
$p = json_decode($rawpostdata,true);

//Dieser try/catch Block wird verwendet um um Fehlerfall die Fehlerspezifikation durchzureichen
try {
  if(is_null($p) and !done()) {
    throw new Exception('Fehlerhafte JSON.');
  }

  if(!isset($p['i']) and !done()) {
    throw new Exception('Instruktion fehlt.');
  }

  if (!done()){ switch ($p['i']) {

    //Dies ist die Hauptfunktion
    //Hier werden alle Daten angefordert
    //Es können durch das mitreichen von Chat und Message IDs, die zu sendenen Daten eingegrenzt werden
    //Die Parameter admin und closed überträgt die Daten für die privilegierte Ansicht und die archivierten Chats
    //Alle unten gelisteten Befehle bekommen als Rückgabewert einen Array zurück welcher JSON-kodiert als Antwort übertragen wird
    case "check-new-data":
      if(!isset($p['last_chats_r'])) $p['last_chats_r'] = null;
      if(!isset($p['last_users'])) $p['last_users'] = null;
      if(!isset($p['admin'])) $p['admin'] = 0;
      if(!isset($p['closed'])) $p['closed'] = 0;
      $return_array = check_new_data($_SESSION['user_id'],$p['last_chats_r'],$p['last_users'],$p['admin'],$p['closed']);
      break;

    //Name ist sprechend
    //Erwartet den Namen des zu erstellenden Chats, sowie ihre Mitglieder (Der Ersteller wird automatisch Admin und muss nicht explizit in der Memberliste erwähnt werden)
    case "create-chat":
      $return_array = create_new_chat($p['name'],$p['members'],$_SESSION['user_id'],1);
      break;

    //Erwartet die ID des Chats sowie die Nachricht
    case "send-message":
      $return_array = send_message($p['chat_id'],$_SESSION['user_id'],$p['msg']);
      break;
    
    //Erwartet die ChatID und die UserID. Der Anfragende muss globaler Admin oder gruppen Admin sein
    case "add-group-member":
      $return_array = add_group_member($p['chat_id'],$_SESSION['user_id'],$p['user']);
      break;
    
    //Erwartet die ChatID und die UserID. Der Anfragende muss globaler Admin oder gruppen Admin sein
    case "del-group-member":
      $return_array = del_group_member($p['chat_id'],$_SESSION['user_id'],$p['user']);
      break;
    
    //Erwartet die ChatID und die UserID. Der Anfragende muss globaler Admin oder gruppen Admin sein
    case "add-group-admin":
      $return_array = set_group_admin($p['chat_id'],$_SESSION['user_id'],$p['user'],1,1);
      break;
      
    //Erwartet die ChatID und die UserID. Der Anfragende muss globaler Admin oder gruppen Admin sein
    case "del-group-admin":
      $return_array = set_group_admin($p['chat_id'],$_SESSION['user_id'],$p['user'],0,1);
      break;
    
    //Archiviert einen Chat. In diesem Chat kann nun nicht mehr interagiert werden.
    //Erwartet die Chat ID und der Anfragende muss global oder gruppen Admin sein.
    case "close-chat":
      $return_array = close_chat($p['chat_id'],$_SESSION['user_id']);
      break;
     
    //Setzt den persönlichen gelesen Status um zu erkennen ob eine Nachricht von einem selber schon gelesen wurde oder nicht.
    case "read-until":
      $return_array = read_until($p['chat_id'],$_SESSION['user_id'],$p['last_msg']);
      break;
        
    //Fragt einen neuen zufälligen Chat an. Der Pool der verfügbaren potentiellen Chatpartner ist aus der Menge der Aktiven Benutzer. Als aktiver User gilt jeder der in den letzen fünf Minuten eine Nachricht geschrieben hat.
    //Wurde erfolgreich ein aktiver User gefunden, wird ein Chat erstellt indem beide Teilnehmer gruppen Admin sind.
    case "request-random-chat":
      $return_array = request_random_chat($_SESSION['user_id']);
      break;
    
    default:
      throw new Exception('Instruktion nicht gefunden.');
      
  }}
  
  //Ist bis hierhin kein Fehler aufgetreten, gilt die Anfrage als erfolgreich.
  if(!isset($return_array['status'])) $return_array['status'] = "success";
  
} catch (Exception $e) {
  
  //Im Falle eines Fehlers wird im catch Block der Status inklusive der Fehlerbeschreibung als JSON übertragen.
  $return_array['status'] = "error";
  $return_array['status_log'] = $e->getMessage();
}

if(isset($p['reqId'])) {
  $return_array['reqId'] = $p['reqId'];
}

//Setzen von eventuellen HTTP Statuscodes
if($return_array['status'] == "error") http_response_code(400);
elseif($return_array['status'] == "unauthorized") http_response_code(401);

//Ausgabe des fertigen Ergebnisses
echo json_encode($return_array);
?>

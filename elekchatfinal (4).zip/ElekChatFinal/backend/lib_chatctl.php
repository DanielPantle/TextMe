<?php
// Name:        chatctl.php
// Author:      Rene Fa
// Date:        14.06.2017
// Version:     1.2
//
// Description:
//  Enthält die erweiterte Logik für das Backend

require "db_access.php";

//################################################################
// Dieser Abschnitt enthält mehrfach verwendete Zwischenbefehle.
//################################################################
function get_last_message($chat_id) {
  global $pdo;

  $sql = $pdo->prepare("SELECT MAX(id) as 'val' FROM chat_messages WHERE chat_id = ?;");
  $ret = $sql->execute(array($chat_id));
  if(!$ret) throw new Exception('Die zuletzt gesendete Nachricht konnte nicht erfasst werden.');
  $row = $sql->fetch();
  return $row['val'];
}

function is_global_admin($uid) {
  if($uid == 0) return true;
  global $pdo;

  $sql = $pdo->prepare("SELECT is_global_admin FROM users WHERE id = ?;");
  $ret = $sql->execute(array($uid));
  if(!$ret) throw new Exception('Der globale Adminstatus konnten nicht gelesen werden.');
  $row = $sql->fetch();
  
  if($row['is_global_admin'] == true) return 1;
  return 0;
}

function is_group_admin($chat_id,$uid) {
  if($uid == 0) return true;
  global $pdo;
  
  $sql = $pdo->prepare("SELECT is_admin FROM chat_members WHERE chat_id = ? and user_id = ?;");
  $ret = $sql->execute(array($chat_id,$uid));
  if(!$ret) throw new Exception('Der Adminstatus konnten nicht gelesen werden.');
  $row = $sql->fetch();
  
  if($row['is_admin'] == true) return 1;

  if(is_global_admin($uid)) return 2;
  return 0;
}

function is_in_group($chat_id,$uid) {
  if($uid == 0) return true;
  global $pdo;
  
  $sql = $pdo->prepare("SELECT * FROM chat_members WHERE chat_id = ? and user_id = ?;");
  $ret = $sql->execute(array($chat_id,$uid));
  if(!$ret) throw new Exception('Es konnte nicht erfasst werden ob der User in der Gruppe ist.');
  $rows = $sql->rowCount();
  
  if($rows > 0) return true;
  return false;  
}

function is_closed($chat_id)
{
  global $pdo;
  
  $sql = $pdo->prepare("SELECT is_closed FROM chats WHERE id = ? and is_closed = 1;");
  $ret = $sql->execute(array($chat_id));
  if(!$ret) throw new Exception('Es konnte nicht erfasst werden ob dieser Chat bereits geschlossen wurde.');
  $rows = $sql->rowCount();
  
  if($rows > 0) return true;
  return false;
}

function xss_prevent($msg) {
  return str_replace('<','&lt;',str_replace('>','&gt;',str_replace('\"','&quot;',$msg)));
}

//################################################################
// Dieser Abschnitt enthält die Hauptbefehle.
//################################################################

// Eine Beschreibung der Befehle ist in chatctl.php zu finden.
// Dort werden die unten aufgeführten Befehle verwendet.

function check_new_data($uid,$last_chats_r,$last_users,$admin,$load_closedChats) {
  $return_array = array();
  global $pdo;
  
  // Selektion des gewünschten Queries. Auswahl hängt von der Adminflag ab
  if($admin == 1) {
    if(is_global_admin($uid) == 1) {
      
      //Selektiert alle Chats welche offen/archiviert sind
      $sql = $pdo->prepare("SELECT id,name FROM chats WHERE is_closed = ? ORDER BY id;");
      $ret = $sql->execute(array($load_closedChats));
    } else {
      throw new Exception('Du bist nicht authorisiert diese Anfrage ausfuehren zu duerfen.');
    }
  } else {
    //Selektiert alle Chats welche in Verbindung mit dem User stehen und offen/archiviert sind
    $sql = $pdo->prepare("SELECT * FROM chats JOIN chat_members ON chat_members.chat_id = chats.id WHERE chat_members.user_id = ? and is_closed = ? ORDER BY id;");
    $ret = $sql->execute(array($uid,$load_closedChats));
  }
  if(!$ret) throw new Exception('Chats konnten nicht geladen werden.');


  //Hauptschleife. Iteriert durch die Chats
  while($row = $sql->fetch()) {
    
    $chat_data['id'] = $row['id'];
    $chat_data['name'] = $row['name'];
    
    // Laden der Nachtichten
    $chat_r = array();
    
    if(isset($last_chats_r[$row['id']]) and !is_null($last_chats_r[$row['id']])){
      $sql2 = $pdo->prepare("SELECT * FROM chat_messages WHERE chat_id = ? AND id > ?;");
      $ret = $sql2->execute(array($row['id'],$last_chats_r[$row['id']]));
    } else {
      $sql2 = $pdo->prepare("SELECT * FROM chat_messages WHERE chat_id = ?;");
      $ret = $sql2->execute(array($row['id']));
    }
    if(!$ret) throw new Exception('Nachrichten konnten nicht geladen werden.');
    
    //Diese Schleife entfernt die nummerierten Felder raus. (Wird häufiger verwendet)
    while($row2 = $sql2->fetch()) {
      for ($i = 0; $i < $sql2->columnCount(); $i++) {
        unset($row2[$i]);
      }
      
      unset($row2['chat_id']);
      $chat_r[] = $row2;
    }
    
    // Laden der Member
    $member_r = array();
    
    if(!isset($last_chats_r[$row['id']]) or is_null($last_chats_r[$row['id']])){
      $sql2 = $pdo->prepare("SELECT * FROM chat_members WHERE chat_id = ?;");
      $ret = $sql2->execute(array($row['id']));
      if(!$ret) throw new Exception('Chat Mitglieder konnten nicht geladen werden.');
      
      while($row2 = $sql2->fetch()) {
        for ($i = 0; $i < $sql2->columnCount(); $i++) {
          unset($row2[$i]);
        }
        
        unset($row2['chat_id']);
        
        //Gibt den momentanen gelesen-Status mit
        if($row2['user_id'] == $uid) $chat_data['read_until'] = $row2['read_until'];
        
        unset($row2['read_until']);
        $member_r[] = $row2;
      }
      
      //Hängt die Member an chat_data ran
      $chat_data['members'] = $member_r;
    }

    $chat_data['messages'] = $chat_r;
    
    //Wenn die Chats nicht leer sind, hänge chat_data ran
    if(count($chat_r) > 0 or is_null($last_chats_r[$row['id']])) $return_array['data']['chats'][] = $chat_data;
    
    //Entferne nach jedem Durchlauf die ID aus dem Anfragearray
    unset($last_chats_r[$row['id']]);
  }
  
  //Alle verbleibenden IDs sind Chats in denen der User kein Mitglied ist/mehr ist.
  //Der User wird darauf aufmerksam gemacht, dass dieeser Chat zu entfernen ist.
  if(count($last_chats_r)) $return_array['data']['delete'] = array_keys($last_chats_r);
  
  // Auflistung aller User
  if(!is_null($last_users)){
    $sql = $pdo->prepare("SELECT * FROM users WHERE id > ?;");
    $ret = $sql->execute(array($last_users));
  } else {
    $sql = $pdo->prepare("SELECT * FROM users;");
    $ret = $sql->execute();
  }
  if(!$ret) throw new Exception('Benutzer konnten nicht geladen werden.');

  while($row = $sql->fetch()) {
    for ($i = 0; $i < $sql->columnCount(); $i++) {
      unset($row[$i]);
    }
     
    unset($row['password']);
    //Anhängen der Userliste an data
    $return_array['data']['users'][] = $row;
  }
  
  //Wenn dies die initiale Anfrage ist, teilt das Backend dem Client seine User_ID mit
  if(is_null($last_users)){
    $return_array['data']['user_id'] = $uid;
  }
  
  //Nach jedem Poll wird der Onlinestempel aktualisiert.
  $sql = $pdo->prepare("UPDATE users SET last_ping=NOW() WHERE id = ?;");
  $ret = $sql->execute(array($uid));
  if(!$ret) throw new Exception('Online Stempel konnte nicht gesetzen werden.');
  
  return $return_array;
}

function create_new_chat($chat_name,$members,$uid,$greeting) {
  $return_array = array();
  global $pdo;
  
  $chat_name = xss_prevent($chat_name);
  
  //Erstellt den Chatkopf
  $sql = $pdo->prepare("INSERT INTO chats (name) VALUES (?);");
  $ret = $sql->execute(array($chat_name));
  if(!$ret) throw new Exception('Chat existiert bereits.');
  
  //Empfängt die neue Chat_id
  $sql = $pdo->prepare("SELECT * FROM chats WHERE name = ?;");
  $ret = $sql->execute(array($chat_name));
  if(!$ret) throw new Exception('Chat konnte nicht geladen werden.');
  
  $row = $sql->fetch();
  $chat_id = $row['id'];

  //Hier wird ein perpared Statement erstellt
  $qstr = "INSERT INTO chat_members (chat_id,user_id,is_admin) VALUES ";
  
  $conditions[] = "(?,?,?)";
  $parameters[] = $chat_id;
  $parameters[] = $uid;
  $parameters[] = true;
  
  for ($i = 0; $i < count($members); $i++) {
    $conditions[] = "(?,?,?)";
    $parameters[] = $chat_id;
    $parameters[] = $members[$i];
    $parameters[] = false;
  }
  
  $sql = $pdo->prepare($qstr . implode(',',$conditions) . ";");
  $ret = $sql->execute($parameters);
  if(!$ret) throw new Exception('Mitglieder konnten nicht hinzugefuegt werden.');
  
  //Erstellt die Initiale Nachricht (Für den Zufallschat kann diese Optional weggelassen werden)
  //Eine UserID von 0 wird automatisch als Systemnachricht vom Client interpretiert
  if($greeting == 1) send_message($chat_id,0,"create_new_chat ".$uid);
  $return_array['chat_id'] = $chat_id;
  return $return_array;
}

function send_message($chat_id,$uid,$msg) {
  $return_array = array();
  
  if($uid != 0 and is_closed($chat_id)) throw new Exception('Dieser Chat ist bereits geschlossen worden.');
  $is_gadmin = is_global_admin($uid);
  if(!is_in_group($chat_id,$uid) and !$is_gadmin) throw new Exception('Du bist nicht Member dieser Gruppe.');
  
  if(!$is_gadmin) $msg = xss_prevent($msg);
  
  global $pdo;

  $sql = $pdo->prepare("INSERT INTO chat_messages (chat_id,user_id,msg) VALUES (?,?,?);");
  $ret = $sql->execute(array($chat_id,$uid,$msg));
  if(!$ret and $uid != 0) throw new Exception('Nachricht kann nicht vom Server gespeicher werden.');
  
  //Setzt den gelesen Status auf die neuste Nachricht
  if($uid) read_until($chat_id,$uid,-1);
  return $return_array;
}

function add_group_member($chat_id,$uid,$t_uid) {
  $return_array = array();
  
  if(is_closed($chat_id)) throw new Exception('Dieser Chat ist bereits geschlossen worden.');
  if(!is_group_admin($chat_id,$uid)) throw new Exception('Dir fehlen die notwendigen Rechte um diese Anfrage auszufuehren.');

  if(is_in_group($chat_id,$t_uid)) throw new Exception('Der angegeben Benutzer wurde bereits hinzugefuegt.');

  global $pdo;

  $last_msg_id = get_last_message($chat_id);

  $sql = $pdo->prepare("INSERT INTO chat_members (chat_id,user_id,read_until) VALUES (?,?,?);");
  $ret = $sql->execute(array($chat_id,$t_uid,$last_msg_id));
  if(!$ret) throw new Exception('Der angegebene Benutzer konnte nicht zur Gruppe hinzuefuegt werden.');
  
  send_message($chat_id,0,"add_group_member ".$uid." ".$t_uid);
  return $return_array;
}

function del_group_member($chat_id,$uid,$t_uid) {
  $return_array = array();
  
  if(is_closed($chat_id)) throw new Exception('Dieser Chat ist bereits geschlossen worden.');
  if(!is_group_admin($chat_id,$uid) and $uid != $t_uid) throw new Exception('Dir fehlen die notwendigen Rechte um diese Anfrage auszufuehren.');

  if(!is_in_group($chat_id,$t_uid)) throw new Exception('Der angegeben Benutzer ist kein Mitglied dieser Gruppe.');

  global $pdo;

  $last_msg_id = get_last_message($chat_id);

  $sql = $pdo->prepare("DELETE FROM chat_members WHERE chat_id = ? and user_id = ?;");
  $ret = $sql->execute(array($chat_id,$t_uid));
  if(!$ret) throw new Exception('Der angegebene Benutzer konnte nicht aus der Gruppe entfernt werden.');
  
  send_message($chat_id,0,"del_group_member ".$uid." ".$t_uid);
  return $return_array;
}

function set_group_admin($chat_id,$uid,$t_uid,$admin_status,$notif) {
  $return_array = array();
  
  if(is_closed($chat_id)) throw new Exception('Dieser Chat ist bereits geschlossen worden.');
  if(!is_group_admin($chat_id,$uid)) throw new Exception('Dir fehlen die notwendigen Rechte um diese Anfrage auszufuehren.');

  if($admin_status == is_group_admin($chat_id,$t_uid)) throw new Exception('Der angegeben Benutzer hat bereits den angeforderten Admin Status.');

  global $pdo;

  $sql = $pdo->prepare("UPDATE chat_members SET is_admin=? WHERE chat_id = ? and user_id = ?;");
  $ret = $sql->execute(array($admin_status,$chat_id,$t_uid));
  if(!$ret) throw new Exception('Der Adminstatus konnte nicht veraendert werden!');
  
  if($notif) send_message($chat_id,0,"group_admin ".$admin_status." ".$uid." ".$t_uid);
  return $return_array;
}

function close_chat($chat_id,$uid) {
  $return_array = array();
  if(is_closed($chat_id)) throw new Exception('Dieser Chat ist bereits geschlossen worden.');
  if(!is_group_admin($chat_id,$uid)) throw new Exception('Dir fehlen die notwendigen Rechte um diese Anfrage auszufuehren.');

  send_message($chat_id,0,"chat_closed ".$uid);

  global $pdo;

  $sql = $pdo->prepare("UPDATE chats SET is_closed=? WHERE id = ?;");
  $ret = $sql->execute(array(1,$chat_id));
  if(!$ret) throw new Exception('Der Chat konnte nicht geschlossen werden.');
  
  return $return_array;
}

function read_until($chat_id,$uid,$last_msg) {
  $return_array = array();
  global $pdo;

  if($last_msg == -1) $last_msg = get_last_message($chat_id);
  
  $sql = $pdo->prepare("UPDATE chat_members SET read_until=? WHERE chat_id = ? and user_id = ?;");
  $ret = $sql->execute(array($last_msg,$chat_id,$uid));
  if(!$ret) throw new Exception('Der gelesen Status konnte nicht aktualisiert werden.');
  
  return $return_array;
}

function request_random_chat($uid) {
  $return_array = array();
  $rlist = array();
  
  global $pdo;
  
  //Selektiert alle aktiven User
  $sql = $pdo->prepare("SELECT * FROM `chat_messages` WHERE `timestamp` >= DATE_SUB(NOW(), INTERVAL 5 MINUTE) GROUP BY `user_id`;");
  $ret = $sql->execute();
  if(!$ret) throw new Exception('Die momentan aktiven User konnten nicht geladen werden.');
  
  while($row = $sql->fetch()) {
    if($row['user_id'] == 0) continue;
    if($row['user_id'] == $uid) continue;
    $rlist[] = $row['user_id'];
  }
  
  //Wenn die Anzahl der aktiven User Null ist
  if(count($rlist) == 0) throw new Exception('Es wurde kein passender Chatpartner gefunden.');

  //Zieht eine Zufallszahl
  $ri = rand(0,count($rlist)-1);
  
  //Erstellung des Zufallschat
  $nc_rr = create_new_chat("random ".time()." ".$uid." ".$rlist[$ri],array($rlist[$ri]),$uid,0);
  send_message($nc_rr['chat_id'],0,"create_random_chat ".$uid." ".$rlist[$ri]);
  set_group_admin($nc_rr['chat_id'],0,$rlist[$ri],1,0);
  
  $return_array['chat_id'] = $nc_rr['chat_id'];
  return $return_array;
}

?>

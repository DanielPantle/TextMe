<?php

require "db_access.php";

// Counts the number of existing Accounts
function user_count(){
  global $pdo;
  $sql = $pdo->prepare("SELECT id FROM users;");
  $sql->execute();
  return $sql->rowCount();
}
//Checks the sent messages within the last # of $hours
function msg_count_per_time($hours){
  global $pdo;
  $sql = $pdo->prepare("SELECT * FROM `chat_messages` WHERE `timestamp` >= DATE_SUB(NOW(), INTERVAL ? HOUR);");
  $sql->execute(array($hours));
  return $sql->rowCount();
}
//Counts the total number of chat messages
function total_chat_messages(){
  global $pdo;
  $sql = $pdo->prepare("SELECT * FROM `chat_messages`");
  $sql->execute();
  $res = $sql->rowCount();
  return $res;
}
//Check how many users have sent messages within the last 5 minutes
function recently_active(){
  global $pdo;
  $sql = $pdo->prepare("SELECT * FROM `chat_messages` WHERE `timestamp` >= DATE_SUB(NOW(), INTERVAL 5 MINUTE) GROUP BY `user_id`;");
  $sql->execute();
  return $sql->rowCount();
}
//Checks how many users have polled within the last 10 seconds, they are "online" and probably still connected to the chat
function online_users(){
  global $pdo;
  $sql = $pdo->prepare("SELECT * FROM `users` WHERE `last_ping` >= DATE_SUB(NOW(), INTERVAL 10 SECOND);");
  $sql->execute();
  return $sql->rowCount();
}
?>

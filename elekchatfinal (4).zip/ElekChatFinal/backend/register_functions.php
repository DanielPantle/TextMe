<?php

require "db_access.php";

// checks if the username is available for registration and for login
function check_username_available($username){
  global $pdo;
  $sql = $pdo->prepare("SELECT * FROM users where name=?;");
  $sql->execute(array($username));
  //if there is no result from query the name is available, otherwise its not
  if($sql->rowCount() != 0){
    return false;
  }
  else{
    return true;
  }
}
//creates the user
function create_user($username, $pwd){
  global $pdo;

  $sql = $pdo->prepare("INSERT INTO users (name,password) VALUES (?,?);");
  $sql->execute(array($username, $pwd));

  echo 'User erfolgreich angelegt';
  echo '<a href="/login.php">Zum Login</a>';
}
//checks if the given username and password match - required for login
function authenticate_user($username, $pwd){
  $password_correct = false;

  global $pdo;

  $sql = $pdo->prepare("SELECT * FROM users where name=?;");
  $sql->execute(array($username));

  $result = $sql->fetch();
  //returns the user database entry if the password is correct - else it returns -1
  if(password_verify($pwd, $result['password'])){
    return $result;
  }
  else{
    return -1;
  }
}
?>
